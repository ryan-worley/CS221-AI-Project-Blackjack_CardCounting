function [error] = leastSquares(datax, datay, median, sigmaln)
error = sum((datay - normpdf(datax, median, sigmaln)).^2);
end